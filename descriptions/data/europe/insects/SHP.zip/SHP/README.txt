Hyalomma Marginatum

Data in file comes from the publication: Estrada-Peña A, de la Fuente J, Latapia T, Ortega C (2015) The Impact of Climate Trends on a Tick Affecting Public Health: A Retrospective Modeling Approach for Hyalomma marginatum (Ixodidae). PLoS ONE 10(5): e0125760. doi:10.1371/journal.pone.0125760
License: Copyright: © 2015 Estrada-Peña et al. This is an open access article distributed under the terms of the Creative Commons Attribution License, which permits unrestricted use, distribution, and reproduction in any medium, provided the original author and source are credited.

Ixodes Ricinus and Aedes Albopictus

The data is avaible on the webpages:
https://en.wikipedia.org/wiki/Aedes_albopictus#Distribution
https://en.wikipedia.org/wiki/Ixodes_ricinus#Distribution
	
Due to the fact that the data from Wikipedia they are covered by CC BY-SA (3.0) license. Data may be shared and adapted for any purpose with appriopriate credit and on the same license as metadata. More information: https://creativecommons.org/licenses/by-sa/3.0/.

Acknowledgement: This application has been developed within the MyGEOSS project, which has received funding from the European Union's Horizon 2020 research and innovation programme.

