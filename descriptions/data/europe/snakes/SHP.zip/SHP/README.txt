European snakes and vipers

The data is avaible on the webpages:
https://en.wikipedia.org/wiki/Macrovipera_schweizeri
https://en.wikipedia.org/wiki/Vipera_xanthina
https://en.wikipedia.org/wiki/Vipera_ammodytes
https://en.wikipedia.org/wiki/Vipera_aspis
https://en.wikipedia.org/wiki/Vipera_berus
https://en.wikipedia.org/wiki/Vipera_latastei
	
Due to the fact that the data from Wikipedia they are covered by CC BY-SA (3.0) license. Data may be shared and adapted for any purpose with appriopriate credit and on the same license as metadata. More information: https://creativecommons.org/licenses/by-sa/3.0/.

Acknowledgement: This application has been developed within the MyGEOSS project, which has received funding from the European Union's Horizon 2020 research and innovation programme.