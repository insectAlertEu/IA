Ixodes Ricinus Tick in Czech Republic

Metadata Description
Borreliosis is a disease caused by ticks from Ixodes genus. The National Institute of Public
Health [1] provides data of number of those infected by districts in Czech Republic. The incidence
rate from 2012 was divided into five parts – the minimum value of disease is 1 and maximum value
is 252. These data set will be used in Insect Alert web application.

Data access and policies

The information about borreliosis could be found on The Czech's Republic National Institute
of Public Health’s webpage [2]. The direct weblink to the obtained data is as follows: [3]. Data on
this sites is licensed by CC BY-SA 3.0. Data may be shared and adapted for any purpose with
appriopriate credit and on the same license as metadata. More information: [4].

Data sharing and use
Dataset will be provided in the final report with .shp and .csv files attached as open access
based on Creative Commons Attribution-Share Alike (3.0) license with appriopriate credits
([1],[2],[3]).

Links:
[1] http://www.szu.cz/niph
[2] http://www.szu.cz/tema/prevence/lymeska-borrelioza
[3] http://www.szu.cz/tema/prevence/lymeska-borrelioza-epidemiologicka-data-do-roku-2013
[4] https://creativecommons.org/licenses/by-sa/3.0/

Acknowledgement: This application has been developed within the MyGEOSS project, which has received funding from the European Union's Horizon 2020 research and innovation programme.

