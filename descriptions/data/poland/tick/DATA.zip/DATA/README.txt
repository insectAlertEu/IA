Ixodes Ricinus Tick in Poland

Metadata Description
Borreliosis is a disease caused by ticks from Ixodes genus. Based on the number of people suffered from this disease Insect Alert estimates the risk factor for each area in Poland.
Documents called „Assessment of sanitary conditio in poviats” are situated on the government’s websites and provides dataset about boreliosis (and other diseases) depends on voivodeship and poviat. Insect Alert uses two indicators from there. The first indicator – incidance rate – is data coming from the one year measurements (2014).

The given formula were used to determine the incidence rate (in Poland):
[number of those infected] * [100 000 habitants] / [population of county].
The -1 value is assigned to the missing data.

Trends in the number of cases in the area over the years is another indicator created and based on the acquired data. The 1 value is assigned to upward trend and -1 value is assigned to downward trend. The value 0 is used for the lack of data.

Data access and policies

Those data is situated on websites of Voivodeship Sanitary–Epidemiological Stations and
Poviat Sanitary-epidemiological Stations. These are public data which are determineted by „Act of 6
September, 2001 on access to public information” and „Act of 16 September 2011 Amending the Act
on Access to Public Information”. The 2.1 paragraph from the „Act on access to public information”
[http://unpan1.un.org/intradoc/groups/public/documents/unpan/unpan034035.pdf] states that each
person is entitled, with the stipulation of Article 5, to the right of access to public information,
hereinafter referred to as “the right to public information”. These two acts allowed users to re-use of
public information for commercial or non-commercial as not infringe copyright.

Data sharing and use
Dataset is provided as the .shp and .csv files attached as open access data.

Acknowledgement: This application has been developed within the MyGEOSS project, which has received funding from the European Union's Horizon 2020 research and innovation programme.

