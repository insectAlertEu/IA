This folders contain information about Heracleum sosnowskyi plant in Poland.

Data is available on the webpage [1-4] in the warnings text. These are public data which are
determineted by „Act of 6 September, 2001 on access to public information” and „Act of 16 September
2011 Amending the Act on Access to Public Information”. The 2.1 paragraph from the „Act on access
to public information”
[http://unpan1.un.org/intradoc/groups/public/documents/unpan/unpan034035.pdf] states that each
person is entitled, with the stipulation of Article 5, to the right of access to public information,
hereinafter referred to as “the right to public information”. These two acts allowed users to re-use of
public information for commercial or non-commercial as not infringe copyright.

Links:
[1] http://www.malopolska.uw.gov.pl/pressarticlepage.aspx?id=7116
[2] https://rzeszow.uw.gov.pl/aktualnosci/straty-podkarpackich-rolnikow-z-powodu-suszy/
[3] http://www.gdansk.uw.gov.pl/urzad/aktualnosci/item/1426-pomorskie-miejsca-wystepowania-
barszczu-sosnowskiego
[4] http://www.lubuskie.uw.gov.pl/aktualnosci/wydarzenia/idn:11221.html

Acknowledgement: Data is contained in insect-alert.eu web application. This application has been developed within the MyGEOSS project, which has received funding from the European Union's Horizon 2020 research and innovation programme.